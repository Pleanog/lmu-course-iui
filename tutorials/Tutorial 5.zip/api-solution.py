# requires
# pip install flask flask-cors
from flask import Flask, request, jsonify
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

# Define Ollama instance configuration
OLLAMA_URL = "https://llm-keyboard.medien.ifi.lmu.de/iui/ollama/api/generate"

# Function to interact with Ollama instance for sentiment analysis
def analyze_sentiment_with_ollama(prompt, model="llama3.1"):
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "temperature": 0.2,
        "resp_format": "json",
    }
    response = requests.post(OLLAMA_URL, headers=headers, json=payload)

    if response.status_code == 200:
        response_json = response.json()
        return response_json.get("response", "").strip()
    else:
        print(f"Error: {response.status_code} - {response.text}")
        return None



# Define the API endpoint for sentiment analysis
@app.route('/api/sentiment', methods=['POST'])
def analyze_sentiment():
    try:
        # Get JSON data from the client request
        data = request.get_json()

        # Validate the input
        if 'text' not in data:
            return jsonify({"error": "Missing 'text' field in the request"}), 400

        text = data['text']
        prompt = f"Determine the sentiment of the following text as Positive, Negative:\n```\n{text}\n```\nRespond only using the label for the sentiment."

        # Get sentiment from Ollama
        sentiment = analyze_sentiment_with_ollama(prompt)

        # Return the result as a JSON response
        return jsonify({"text": text, "sentiment": sentiment})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Run the Flask app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
